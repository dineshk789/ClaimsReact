import React from 'react';
 import{ Navbar,Nav, Form ,FormControl,Button} from 'react-bootstrap';
 import {connect} from 'react-redux';
class NavigationBar extends React.Component {
    constructor(props) {  
      super(props);
    var today = new Date(),
     
   time = today.getDate()+ '-'  + (today.getMonth() + 1) + '-' + today.getFullYear() + ' '  + today.getHours() + ':' + today.getMinutes();   

    this.state = {
      currentTime: time,
      user:""
    }

  }

   //componentDidMount() {
   // const user = localStorage.getItem('user');    
   // this.setState({ user });   
  //}

   render() {
   const today= this.state

   //const {user}= this.state
    console.log('Header: this.props.state', this.props);
      return (
      <div>

<Navbar bg="dark" variant="dark">
  
  <Navbar.Toggle />
  <Navbar.Collapse className="justify-content-end">
    <Navbar.Text  className="mr-sm-2  text-white " >
    <a>    { today.currentTime }   </a>
    </Navbar.Text>
    <Navbar.Text className="mr-sm-2  text-white" >
        Signed in as: <a href="#login">{this.props.loggedUsername}</a>
    </Navbar.Text>
  </Navbar.Collapse>
</Navbar>
 
    </div>
      )
   }
}

const mapStateToProps = state => {
    console.log('App state loggedinuser', state);
    return {loggedUsername: state.LoginReducer};
}
 

export default connect(mapStateToProps)(NavigationBar);





