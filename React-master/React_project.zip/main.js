import React from 'react';
import ReactDOM from 'react-dom';

import LoginForm from './component/login/LoginForm.jsx';
import Headers from './component/common/Header.jsx';
import DashboardForm from './component/home/DashboardForm.jsx';
import Footer from './component/common/Footer.jsx';
import ViewForm from './component/view_claim/ViewForm.jsx';
import UpdateForm from './component/update/UpdateForm.jsx';
import Contact from './component/contact/Contact.jsx';
import { Router, Route, Link, browserHistory, IndexRoute  } from 'react-router';
import Menu from './Menu.jsx';

// json object here ReactDOM.render(<Hello name='sreeram' age='30'/>, document.getElementById('app'));
//ReactDOM.render(<LoginHeader/>, document.getElementById('header'));
//ReactDOM.render(<LoginForm/>, document.getElementById('form'));
//ReactDOM.render(<LoginFooter/>, document.getElementById('footer'));




//ReactDOM.render(<Headers/>, document.getElementById('header'));
//ReactDOM.render(<ViewForm/>, document.getElementById('form'));

//ReactDOM.render(<DashboardForm/>, document.getElementById('form'));

//ReactDOM.render(<UpdateForm/>, document.getElementById('form'));

//ReactDOM.render(<Footer/>, document.getElementById('footer'));



ReactDOM.render( 

   <Router history = {browserHistory}>  
   <Route path = "/" component = {Menu}>       
   <IndexRoute component = {LoginForm} />       
   <Route path = "DashboardForm" component = {DashboardForm} />    
   <Route path = "ViewForm" component = {ViewForm} />    
   <Route path = "UpdateForm/:claimId"  component = {(props) => <UpdateForm {...props}/>}/> 
   <Route path = "Contact" component = {Contact} />    
    <Route path = "LoginForm" component = {LoginForm} />  
    
   </Route>  
    </Router> 
    ,
    document.getElementById('root'));