
 import React from 'react';
 import Table from 'react-bootstrap/Table'

 import{ Navbar,Nav, Form ,FormControl,Button,Container,Row,Col} from 'react-bootstrap';
import { Router, Route, Link,NavLink,  browserHistory, IndexRoute  } from 'react-router';
 import NavigationBar from './../common/Navigation.jsx';
class Contact extends React.Component {

	render() {
   
    return(
    	<div>
    	 <NavigationBar/>
   <Navbar  style={{backgroundColor:"#861e71"}} variant="dark">
      
    <Nav className="mr-auto">   
     <Nav.Link  href="#home" as={Link} to="DashboardForm">Home</Nav.Link> 
      <Nav.Link  href="#viewForm" as={Link} to="ViewForm">View Claim</Nav.Link>  
      <Nav.Link href="#updateForm" as={Link}  to="UpdateForm">Update Claim</Nav.Link>
      <Navbar.Brand href="#Contact" as={Link} to="Contact">Contact Us</Navbar.Brand>  
    </Nav>
     <Nav>
     <Nav.Link href="#Singout" as={Link}  to="LoginForm">Signout</Nav.Link>    
    </Nav>
  </Navbar>
<section>
<div >
	<Container>
  <Row className="justify-content-md-center">
    <Col xs lg="2">
      <p> <b>Write to us:</b>
 	</p>
 	<p>  We'll write rarely, but only the best content.
 	</p>
  <p> sale@sales.com
 </p>
    </Col>
    
  </Row>  
</Container>

  </div>
 </section>
</div>
     );
  }
}
export default Contact;