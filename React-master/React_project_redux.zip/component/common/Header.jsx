import React from 'react';
import{ Navbar,Nav, Form ,FormControl,Button}from 'react-bootstrap';
class Headers extends React.Component {
   render() {      
                   
      return (   // Render fucction is life cycle hook which render template
  
 <Navbar bg="dark" variant="dark">
  <h2 className="row col-12 d-flex justify-content-center text-white">CLAIM MANAGEMENT PORTAL</h2>
   
</Navbar>


      );
   }
}

export default Headers;   
