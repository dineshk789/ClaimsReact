
 import React from 'react';
import{ Navbar,Nav, Form ,FormControl,Button}from 'react-bootstrap';
import { Router, Route, Link,NavLink,  browserHistory, IndexRoute  } from 'react-router';
 import NavigationBar from './../common/Navigation.jsx';
class DashboardForm extends React.Component {

	render() {

    return(
 <div>
 <NavigationBar/>
   <Navbar  style={{backgroundColor:"#861e71"}} variant="dark">
      
    <Nav className="mr-auto">   
     <Navbar.Brand href="#home" as={Link} to="DashboardForm">Home</Navbar.Brand>  
      <Nav.Link  href="#viewForm" as={Link} to="ViewForm">View Claim</Nav.Link>  
      <Nav.Link href="#updateForm" as={Link}  to="UpdateForm">Update Claim</Nav.Link>
      <Nav.Link href="#contact" as={Link} to="Contact">Contact Us</Nav.Link>
    </Nav>
     <Nav>
     <Nav.Link href="#Singout" as={Link}  to="LoginForm">Signout</Nav.Link>    
    </Nav>
  </Navbar>
<section>
<div >

  <p> <b>Welcome Claim Management</b></p>


 	<p> <b>Lorem Ipsum</b> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum

 	</p>
 	<p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum

 	</p>
  <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum

 </p>
  </div>
 </section>
</div>
     );
  }
}
export default DashboardForm;

