import React from 'react';

import axios from 'axios';
import { Router, Route, Link, browserHistory, IndexRoute  } from 'react-router';

class ClaimList extends React.Component {
  
 constructor(props){
   
  super(props);
  this.state = {
    claims: []
  }
this.handleSubmit = this.handleSubmit.bind(this)
this.showUpdate = this.showUpdate.bind(this);
}
  componentDidMount() {
    axios.get(`http://localhost:7000/claims`)
      .then(res => {       
        const claims = res.data;        
        this.setState({ claims });
      })
  }

   showUpdate(thisClaim) {
    window.event.preventDefault();
      console.log('updating claim', thisClaim.emp_id);
     browserHistory.push('UpdateForm/'+thisClaim.emp_id);
      //this.setState({showUpdate: true, selectedClaim: thisClaim})
   }

handleSubmit(claim){
    
   console.log("heree");
   // if(validateForm(this.state.errors)) {
    //  console.info('Valid Form')
    browserHistory.push('UpdateForm');
    //}else{
   //   console.error('Invalid Form')
   // }
  }
  render() {
    let showUpdateContent = this.showUpdate;
    console.log("State::"+this.state);
    
     //   var myJSON = JSON.stringify(cla); 
    //    console.log("Type4: " +  myJSON); 
  
     
    let myTr="";
    
    myTr= this.state.claims.map(function(claim, index){
               return (<tr key={index}><td>{claim.emp_id}</td>
                      <td>{claim.emp_name}</td>
                      <td>{claim.claim_number}</td>
                      <td>{claim.claim_type}</td>
                      <td>{claim.claim_program}</td>
                      <td>{claim.start_date}</td>
                      <td>{claim.end_date}</td>
                      <td ><a className="updateTdBut" href="" onClick={() => showUpdateContent(claim)} >Update</a></td>
                </tr>)
        });

   return myTr;       

 }    
  
}

export default ClaimList;